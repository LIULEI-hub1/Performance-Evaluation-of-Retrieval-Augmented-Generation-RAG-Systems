classdef selfAttentionLayer < nnet.layer.Layer
    
    properties (Learnable)
        % 可学习参数 : attention层的权重矩阵，可增强模型的拟合能力
        Weight_Q
        Weight_K
        Weight_V
    end
        
    
    methods
        function layer = selfAttentionLayer(numhiddensize,name)
            layer.Name = name;
            %权值矩阵初始化
            layer.Weight_Q = randn(numhiddensize,numhiddensize);
            layer.Weight_K = randn(numhiddensize,numhiddensize);
            layer.Weight_V = randn(numhiddensize,numhiddensize);
        end
        function Y = predict(layer, X)
            
              %使用矩阵相乘代替点乘，可以省去后面的加权求和操作
              %矩阵相乘本身包含求和过程，加权只需要外加归一化函数加dot即可实现
          if ndims(X) == 2
               
               X_MAT = X';
               Q = X_MAT*layer.Weight_Q; %对输入进行线性变换得到Query
               K = X_MAT*layer.Weight_K; %对输入进行线性变换得到Key
               V = X_MAT*layer.Weight_V; %对输入进行线性变换得到Value
               Similarity = Q.*K;  %相似度矩阵
               dk = size(K,2); %键向量维度
               Similarity = Similarity/sqrt(dk); %Scale操作，防止梯度爆炸
               Similarity = Similarity'; %转置，便于下面的归一化操作
               Similarity = softmax(Similarity,'DataFormat','CB'); %归一化，为每个元素赋权
               Scores = Similarity'; %转置回来得到注意力得分
               Y = Scores.*V; %最终的注意力矩阵
               Y = Y'; %转换成下一层的输入格式
               
               %Y = tanh(Y); %激励函数
           end
           
          
           if ndims(X) == 3
               
               X_MAT = squeeze(X); %前置层降维
               X_MAT = X_MAT';
               Q = X_MAT*layer.Weight_Q; %对输入进行线性变换得到Query
               K = X_MAT*layer.Weight_K; %对输入进行线性变换得到Key
               V = X_MAT*layer.Weight_V; %对输入进行线性变换得到Value
               Similarity = Q.*K;  
               dk = size(K,2); %键向量维度
               Similarity = Similarity/sqrt(dk); %Scale操作，防止梯度爆炸
               Similarity = Similarity'; %转置，便于下面的归一化操作
               Similarity = softmax(Similarity,'DataFormat','CB'); %归一化，为每个元素赋权
               Similarity = Similarity'; %转置回来
               Y = Similarity.*V; %加权求和
               Y = reshape(Y,size(X));
               %Y = tanh(Y); %激励函数
           end

        end
    end
end