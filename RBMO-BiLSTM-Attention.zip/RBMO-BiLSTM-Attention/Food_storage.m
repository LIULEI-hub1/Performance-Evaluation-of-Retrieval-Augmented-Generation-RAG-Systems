
function [fit, X, fit_old, X_old] = Food_storage(fit, X, fit_old, X_old)
    Inx = (fit_old < fit);
    Indx = repmat(Inx, 1, size(X, 2));
    X = Indx .* X_old + ~Indx .* X;
    fit = Inx .* fit_old + ~Inx .* fit;
    fit_old = fit;
    X_old = X;
end